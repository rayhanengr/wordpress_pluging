<?php

require_once MONSTERINSIGHTS_PLUGIN_DIR . 'pro/includes/gutenberg/blocks/blocks.php';
