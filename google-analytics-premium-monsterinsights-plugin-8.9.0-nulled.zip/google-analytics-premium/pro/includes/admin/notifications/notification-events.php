<?php

$base = MonsterInsights();
require_once plugin_dir_path( $base->file ) . '/pro/includes/admin/notifications/notification-connect-search-console.php';
require_once plugin_dir_path( $base->file ) . '/pro/includes/admin/notifications/notification-ecommerce-low-conversion-rate.php';
require_once plugin_dir_path( $base->file ) . '/pro/includes/admin/notifications/notification-ecommerce-low-revenue.php';
require_once plugin_dir_path( $base->file ) . '/pro/includes/admin/notifications/notification-ecommerce-removed-from-cart.php';
require_once plugin_dir_path( $base->file ) . '/pro/includes/admin/notifications/notification-scroll-depth.php';
require_once plugin_dir_path( $base->file ) . '/pro/includes/admin/notifications/notification-no-addons.php';
require_once plugin_dir_path( $base->file ) . '/pro/includes/admin/notifications/notification-no-traffic.php';
require_once plugin_dir_path( $base->file ) . '/pro/includes/admin/notifications/notification-pro-eu-traffic.php';
require_once plugin_dir_path( $base->file ) . '/pro/includes/admin/notifications/notification-to-enable-author-tracking.php';
require_once plugin_dir_path( $base->file ) . '/pro/includes/admin/notifications/notification-to-enable-custom-dimensions.php';
require_once plugin_dir_path( $base->file ) . '/pro/includes/admin/notifications/notification-to-enable-ecommerce-tracking.php';
require_once plugin_dir_path( $base->file ) . '/pro/includes/admin/notifications/notification-to-enable-email-summaries.php';
require_once plugin_dir_path( $base->file ) . '/pro/includes/admin/notifications/notification-to-setup-google-optimize.php';
require_once plugin_dir_path( $base->file ) . '/pro/includes/admin/notifications/notification-to-track-categories.php';
require_once plugin_dir_path( $base->file ) . '/pro/includes/admin/notifications/notification-to-track-form-submission.php';
